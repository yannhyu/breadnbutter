Lightweight Django Code Examples
================================

This repository contains all the code from the book, `Lightweight Django <http://shop.oreilly.com/product/0636920032502.do>`_
by `Julia Elman <https://github.com/juliaelman>`_ and `Mark Lavin <https://github.com/mlavin>`_.


Using These Examples
--------------------------------

The various folders in the book correspond to the projects created throughout the book.
